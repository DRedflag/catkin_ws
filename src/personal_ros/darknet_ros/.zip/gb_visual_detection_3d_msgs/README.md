# gb_visual_detection_3d_msgs
Provide messages for darknet_ros_3d and yolact_ros_3d
