#!/usr/bin/env python3
from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QStatusBar, QSlider, QLabel
from PyQt5 import uic
import sys, os
from interbotix_xs_modules.arm import InterbotixManipulatorXS

ROBOT_MODEL = "rx150"

class UI(QMainWindow):
    def __init__(self):
        super().__init__()

        # Load the UI file
        dir = os.path.join(os.path.dirname(__file__), 'theme/mainwindow.ui')
        uic.loadUi(dir, self)
 
        # Show the window
        self.show()

        # Find child 
        self.StartSimButton = self.findChild(QPushButton, "btnStartRobotSimulation")
        self.StartRealButton = self.findChild(QPushButton, "btnStartRobotReal")
        self.PickAndPlace = self.findChild(QPushButton, "btnStartRobotPickPlace")

        self.yPlus = self.findChild(QPushButton, "btnYplus")
        self.yMinus = self.findChild(QPushButton, "btnYminus")
        self.xPlus = self.findChild(QPushButton, "btnXplus")
        self.xMinus = self.findChild(QPushButton, "btnXminus")
        self.zPlus = self.findChild(QPushButton, "btnZplus")
        self.zMinus = self.findChild(QPushButton, "btnZminus")

        self.Joint1 = self.findChild(QSlider, "horizontalSliderJoint1")
        self.Joint2 = self.findChild(QSlider, "horizontalSliderJoint2")
        self.Joint3 = self.findChild(QSlider, "horizontalSliderJoint3")
        self.Joint4 = self.findChild(QSlider, "horizontalSliderJoint4")
        self.Joint5 = self.findChild(QSlider, "horizontalSliderJoint5")
        self.Joint6 = self.findChild(QSlider, "horizontalSliderJoint6")

        self.J1Val = self.findChild(QLabel, "J1Value")
        self.J1Val = self.findChild(QLabel, "J2Value")
        self.J1Val = self.findChild(QLabel, "J3Value")
        self.J1Val = self.findChild(QLabel, "J4Value")
        self.J1Val = self.findChild(QLabel, "J5Value")


        # Setting for QSlider
        self.Joint1.setValue(0)
        self.Joint1.setMinimum(-314)
        self.Joint1.setMaximum(314)
        self.Joint1.setSingleStep(1)

        self.Joint2.setValue(0)
        self.Joint2.setMinimum(-184)
        self.Joint2.setMaximum(174)
        self.Joint2.setSingleStep(1)

        self.Joint3.setValue(0)
        self.Joint3.setMinimum(-177)
        self.Joint3.setMaximum(165)
        self.Joint3.setSingleStep(1)

        self.Joint4.setValue(0)
        self.Joint4.setMinimum(-174)
        self.Joint4.setMaximum(214)
        self.Joint4.setSingleStep(1)

        self.Joint5.setValue(0)
        self.Joint5.setMinimum(-314)
        self.Joint5.setMaximum(314)
        self.Joint5.setSingleStep(1)

        self.Joint1.valueChanged.connect(self.update_joint_1)
        self.Joint2.valueChanged.connect(self.update_joint_2)
        self.Joint3.valueChanged.connect(self.update_joint_3)
        self.Joint4.valueChanged.connect(self.update_joint_4)
        self.Joint5.valueChanged.connect(self.update_joint_5)

        # if ROBOT_MODEL == "vx300s":
        #     self.Joint6.valueChanged.connect(self.update_joint_6)


        # Funct for QPushButton
        self.StartSimButton.clicked.connect(self.start_sim)
        self.StartRealButton.clicked.connect(self.start_real)
        # self.StartRealButton.clicked.connect(self.pick_and_place)

    

    def start_sim(self):
        self.bot = InterbotixManipulatorXS(ROBOT_MODEL, "arm", "gripper")
        os.system("roslaunch interbotix_xsarm_control xsarm_control.launch robot_model:=rx150 use_sim:=true")

    def start_real(self):
        self.bot = InterbotixManipulatorXS(ROBOT_MODEL, "arm", "gripper")
        os.system("roslaunch interbotix_xsarm_control xsarm_control.launch robot_model:=rx150 use_sim:=false")

    def update_joint_1(self, value):
        self.J1Val.setText(str(value/100))
        # self.bot.arm.set_single_joint_position("waist", value/100)

    def update_joint_2(self, value):
        self.J1Val.setText(str(value/100))
        # self.bot.arm.set_single_joint_position("shoulder", value/100)

    def update_joint_3(self, value):
        self.J1Val.setText(str(value/100))
        # self.bot.arm.set_single_joint_position("elbow", value/100)

    def update_joint_4(self, value):
        self.J1Val.setText(str(value/100))
        # self.bot.arm.set_single_joint_position("wrist_angle", value/100)

    def update_joint_5(self, value):
        self.J1Val.setText(str(value/100))
        # self.bot.arm.set_single_joint_position("wrist_rotate", value/100)


if __name__ == "__main__":
    app = QApplication([])
    window = UI()   
    app.exec_()
