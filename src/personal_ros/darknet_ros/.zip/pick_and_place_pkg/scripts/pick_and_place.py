#!/usr/bin/env python3

import math
import rospy
import numpy as np
from interbotix_xs_modules.arm import InterbotixManipulatorXS
import interbotix_common_modules.angle_manipulation as ang
from interbotix_perception_modules.armtag import InterbotixArmTagInterface
from pick_and_place_pkg.srv import norm_srv, norm_srvRequest, norm_srvResponse
import tf2_ros
from tf.transformations import euler_from_quaternion
from geometry_msgs.msg import Point, TransformStamped, Quaternion

#Set up new sleep pose
def go_to_sleep_pose():
    bot.arm.set_joint_positions([0, -1.80, 1.65, 0.8, 0]) #RX150

#### Discuss ####
def get_object_infor():
    rospy.wait_for_service("/norm_srv")
    client = rospy.ServiceProxy("/norm_srv", norm_srv)
    req = norm_srvRequest()
    res = norm_srvResponse()
    res = client.call(req)
    points = [res.point_1, res.point_2]
    success, points_final = transform(points)
    
    A = (points_final[0].x, points_final[0].y, points_final[0].z)
    N = (points_final[1].x, points_final[1].y, points_final[1].z)
    return A,N

def transform(points: list):
    br = tf2_ros.TransformBroadcaster()
    tfBuffer = tf2_ros.Buffer()
    listener = tf2_ros.TransformListener(tfBuffer)
    ref_frame = "rx150/base_link"
    cluster_frame= "camera_link"
    try:
        trans = tfBuffer.lookup_transform(ref_frame, cluster_frame, rospy.Time(0), rospy.Duration(4.0))
    except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException):
        rospy.logerr("Failed to look up the transform from '%s' to '%s'." % (ref_frame, cluster_frame))
        return False, []
    
    x = trans.transform.translation.x
    y = trans.transform.translation.y
    z = trans.transform.translation.z
    quat = trans.transform.rotation
    q = [quat.x, quat.y, quat.z, quat.w]
    rpy = euler_from_quaternion(q)
    T_rc = ang.poseToTransformationMatrix([x, y, z, rpy[0], rpy[1], rpy[2]])

    points_final =[]
    for i in range(len(points)):
        p_co = [points[i].x, points[i].y, points[i].z, 1]
        p_ro = np.dot(T_rc, p_co)
        point = Point()
        point.x = p_ro[0]
        point.y = p_ro[1]
        point.z = p_ro[2]
        points_final.append(point)

    time_now = rospy.Time.now()

    trans = TransformStamped()
    trans.header.frame_id = ref_frame
    trans.header.stamp = time_now
    trans.child_frame_id = "Point"
    trans.transform.translation.x = points_final[0].x
    trans.transform.translation.y = points_final[0].y
    trans.transform.translation.z = points_final[0].z
    trans.transform.rotation = Quaternion(0, 0, 0, 1)
    br.sendTransform(trans)

    return True, points_final

# Kiem tra
def checking_action_for_perpendicular():
    actions = []
    actions.append(bot.arm.set_ee_pose_components(x=A[0]- safety_height, y=A[1], z=A[2], execute=False)[1])
    actions.append(bot.arm.set_ee_pose_components(x=A[0], y=A[1], z=A[2], execute=False)[1])
    actions.append(bot.arm.set_ee_pose_components(x=A[0], y=A[1], z=A[2]+safety_height, execute=False)[1])
    actions.append(bot.arm.set_ee_pose_components(x=A[0], y=A[1], z=A[2]+safety_height, roll = 1.57, execute=False)[1])
    actions.append(bot.arm.set_ee_pose_components(x=B[0], y=B[1], z=B[2], roll= math.atan2(B[1], B[0]) + B[3], pitch= B[4], execute=False)[1])
    check = all(actions)
    if not check:
        rospy.logerr("False")
    return check
 
def checking_action_for_lie_on_xy_plane(angle):
    actions = []
    actions.append(bot.arm.set_ee_pose_components(x=A[0], y=A[1], z=A[2] + safety_height+gripper_buff + object_height/2, roll = math.atan2(A[1], A[0]) + angle, pitch=1.57, execute=False)[1])
    actions.append(bot.arm.set_ee_pose_components(x=A[0], y=A[1], z=A[2], roll = math.atan2(A[1], A[0]) + angle, pitch=1.57, execute=False)[1])
    actions.append(bot.arm.set_ee_pose_components(x=A[0], y=A[1], z=B[2], roll = math.atan2(A[1], A[0]) + angle, pitch=1.57, execute=False)[1])
    actions.append(bot.arm.set_ee_pose_components(x=B[0], y=B[1], z=B[2], roll= math.atan2(B[1], B[0]) + B[3], pitch= B[4], execute=False)[1])
    check = all(actions)
    if not check:
        rospy.logerr("False")

    return check

# A = (x_A, y_A, z_A) - Trong tam cua vat 
# N = (x_N, y_N, z_N) - 1 Diem theo chieu dai cua vat
# B - Diem tha vat
def gap_vat_voi_huong(A: tuple, N: tuple, B: tuple):
    AN_unit_vector =[N[0]-A[0], N[1]-A[1], N[2]-A[2]] / np.linalg.norm([N[0]-A[0], N[1]-A[1], N[2]-A[2]])
    xy_normal_vector = np.array((0,0,1))
    dot_product = np.dot(AN_unit_vector, xy_normal_vector)
    angle_AN_xy_normal = np.arccos(dot_product)
    
    if angle_AN_xy_normal > 1.57:
        angle_AN_xy_normal = 3.14 - angle_AN_xy_normal
    elif angle_AN_xy_normal <-1.57:
        angle_AN_xy_normal = -3.14 - angle_AN_xy_normal

    ### Perpendicular to XY Plane
    if angle_AN_xy_normal <= 10*(3.14/180):
        bot.arm.go_to_sleep_pose()
        available = checking_action_for_perpendicular()
        if available:
            bot.arm.set_ee_pose_components(x=A[0]-safety_height, y=A[1], z=A[2])
            bot.gripper.open()
            bot.arm.set_ee_pose_components(x=A[0], y=A[1], z=A[2])
            bot.gripper.close()
            rospy.sleep(1.5)
            bot.arm.set_ee_pose_components(x=A[0], y=A[1], z=A[2]+safety_height)
            bot.arm.set_ee_pose_components(x=A[0], y=A[1], z=B[2]+safety_height, roll = 1.57)
            bot.arm.set_ee_pose_components(x=B[0], y=B[1], z=B[2], roll= math.atan2(B[1], B[0]) + B[3], pitch= B[4])
            bot.gripper.open()

    ### Lies on XY Plane
    else:  
        AN_unit_vector =[N[0]-A[0], N[1]-A[1]] / np.linalg.norm([N[0]-A[0], N[1]-A[1]]) 
        x_unit_vector = np.array((1,0))
        dot_product = np.dot(AN_unit_vector, x_unit_vector)
        angle = np.arccos(dot_product)

        if angle > 1.57:
            angle = 3.14 - angle
            
        if N[1] > 0:
            angle *= -1

        available = checking_action_for_lie_on_xy_plane(angle)
        if available:
            bot.arm.go_to_sleep_pose
            bot.arm.set_ee_pose_components(x=A[0], y=A[1], z=A[2] + safety_height + gripper_buff + object_height/2, roll = math.atan2(A[1], A[0])+angle, pitch=1.57)
            bot.gripper.open()
            bot.arm.set_ee_pose_components(x=A[0], y=A[1], z=A[2]+0.01, roll = math.atan2(A[1], A[0])+angle, pitch=1.57)
            bot.gripper.close()
            rospy.sleep(1)
            bot.arm.set_ee_pose_components(x=A[0], y=A[1], z=B[2], roll = math.atan2(A[1], A[0])+angle, pitch=1.57)
            bot.arm.set_ee_pose_components(x=B[0], y=B[1], z=B[2], roll= math.atan2(B[1], B[0]) + B[3], pitch= B[4])
            bot.gripper.open()

    if not available:
        print("*_"*20)    
        print("The object(s) is out of the working space of robot.")
        print("Please check the position of the object.")    
        print("*_"*20)    

    bot.arm.go_to_home_pose()

    return available

def gap_nhieu_vat_lien_tiep(objects_, B: tuple):
    num_objects = len(objects_)
    objects_ordered = sorted(objects_, key= lambda x: x[0], reverse= False)
    collector = []
    for i in range(num_objects):
        A = objects_[i].A
        N = objects_[i].N 
        available = gap_vat_voi_huong(A, N, B)    
        collector.append(available)

    go_to_sleep_pose()

    return print(f"{round(len(collector)/num_objects*100,2)}% objects are collected")


if __name__ == "__main__":
    bot = InterbotixManipulatorXS("rx150", "arm", "gripper")
    armtag = InterbotixArmTagInterface()
    while True:
        if armtag.find_ref_to_arm_base_transform():
            break

    safety_height = 4*0.01 #Safety space
    object_height = 2.4*0.01 #Object's height
    gripper_buff = 0.015

    finish = True
    while finish:
        # get_objects_infor()
        B = (0, -0.25, 0.065, 0, 1.57)
        gap_nhieu_vat_lien_tiep(objects_, B)

        check = ''
        while check != 'Y' and check != 'N':
            check = input(
                "Do you want to repeat the process?(Y/N)\n").upper()
            if check.upper() == 'N':
                finish = False
                break

    check = ''
    while check != 'Y' and check != 'N':
        check = input("Exit?(Y/N)\n").upper()
        if check.upper() == 'Y':
            break