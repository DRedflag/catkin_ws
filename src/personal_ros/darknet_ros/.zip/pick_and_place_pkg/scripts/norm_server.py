#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Point
from pick_and_place_pkg.srv import norm_srv, norm_srvResponse

A = Point()
N = Point()

def update_A(me: Point):
    global A
    A = me

def update_N(me2: Point):
    global N
    N = me2

def call_back(req):
    res = norm_srvResponse()
    res.point_1 = A
    res.point_2 = N
    return res.point_1, res.point_2

if __name__ == "__main__":
    rospy.init_node("Norm_Server")

    sub_A = rospy.Subscriber("/A_topic", Point, update_A)
    sub_N = rospy.Subscriber("/N_topic", Point, update_N)
    server = rospy.Service("/norm_srv", norm_srv, call_back)

    rospy.spin()