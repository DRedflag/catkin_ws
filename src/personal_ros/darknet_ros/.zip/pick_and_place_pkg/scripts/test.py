# #!/usr/bin/env python3
# import math
# import rospy
# import numpy as np
# from custom_lib.arm import InterbotixManipulatorXS
# import interbotix_common_modules.angle_manipulation as ang

# if __name__ == "__main__":
#     bot = InterbotixManipulatorXS("vx300s", "arm", "gripper")
#     a = 0.266
#     c = 0.09
#     bot.arm.go_to_sleep_pose()
#     A = (0.33, 0, 0.09)
#     N = (0.321, 0, 0)
#     B = (0, 0.25, 0.08, 0, 1.57)
#     safety_height = 4*0.01
#     # theta_list, success = bot.arm.set_ee_pose_components(x= 0.266, z= 0.09, execute=False)
#     # bot.arm.publish_positions(theta_list)
#     # print(bot.arm.get_ee_pose())
#     # a = bot.arm.set_ee_cartesian_trajectory_modif(x=0.02, prev_thetalist=theta_list, execute=False)
#     # a = bot.arm.set_ee_cartesian_trajectory(x= 0.02)
#     # print(a[1])
#     bot.arm.set_ee_pose_components(x=A[0], y=A[1], z=B[2]+safety_height, roll= math.pi/2, pitch= 0.000001)
#     # bot.arm.set_ee_cartesian_trajectory(roll=math.pi/2)
#     T = bot.arm.get_ee_pose()
#     print(T)
#     angles = T[:3,:3]
#     print(angles)
#     abc = ang.rotationMatrixToEulerAngles(angles)
#     print("\n" + str(abc))

list_ = []

for x in range(5):
    A = (5-x, x -2, x+3)
    list_.append(A)

list_sorted = sorted(list_, key= lambda A: A[1])

print(list_)
print(list_sorted)